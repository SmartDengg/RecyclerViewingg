#RxJava


### [Watch Slides →](http://mrfu.me/rxjava-keynote)

<img src="http://huangxuan.me/js-module-7day/attach/qrcode.png" width="350" height="350"/>

<small class="img-hint">你也可以通过扫描二维码在手机上观看</small>

[去 star 我的 Github](https://github.com/MrFuFuFu/rxjava-keynote)

### Thanks

[Reveal.js](http://lab.hakim.se/reveal-js)

[huangxuan](http://huangxuan.me/2015/07/09/js-module-7day/)
