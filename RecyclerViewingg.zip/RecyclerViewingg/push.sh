
git push origin master --tags; 
git push --force origin master:gh-pages --tags;
