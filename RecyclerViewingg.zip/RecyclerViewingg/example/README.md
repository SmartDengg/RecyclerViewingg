This example is placed for talk and demo use.
not optimize for read.

if u want, feel free to use.

from Hux.
