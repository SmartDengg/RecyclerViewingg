// app.js

var button = $("<button />").html("hey").click(function(){
        alert("hey")
    });

$("body").html(button)
