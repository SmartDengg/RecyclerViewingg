var math = require("./math");

console.log(math.add(1,2));

var timeout = require("./timeout");

console.log('timeout done');

