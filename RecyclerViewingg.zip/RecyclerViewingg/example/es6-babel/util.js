

export function getRandom(){
    return Math.random();
}

