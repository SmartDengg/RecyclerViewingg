var math = {
    PI: 3.14,
    foo: function(){ 
        console.log('I am not bar')
    }
}

export default Math;
