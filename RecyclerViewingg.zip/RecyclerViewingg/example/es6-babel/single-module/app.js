import math from './math';
console.log(math);
//console.log( math.PI );
//math.foo();
