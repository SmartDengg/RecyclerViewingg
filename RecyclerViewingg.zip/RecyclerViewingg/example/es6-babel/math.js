// math.js

export function sum(x, y){
    return x+y;
}

export var PI = 3.14;

