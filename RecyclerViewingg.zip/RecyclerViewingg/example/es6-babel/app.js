// app.js

import {PI} from "./math";

console.log(PI);
//console.log(math.sum(math.PI, math.PI));

//import { getRandom } from "./util";

//console.log(getRandom())
